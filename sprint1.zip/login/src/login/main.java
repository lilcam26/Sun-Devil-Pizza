package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;


public class main extends Application {
	
	public static Connection getConnection() throws Exception{
		  try{
		   String driver = "com.mysql.cj.jdbc.Driver";
		   String url = "jdbc:mysql://127.0.0.1:3306/login";
		   String username = "root";
		   String password = "Christian26";
		   Class.forName(driver);
		   
		   Connection conn = DriverManager.getConnection(url,username,password);
		   System.out.println("Connected");
		   return conn;
		  } catch(Exception e)
		  	{
			  System.out.println(e);
			 }
		  return null;
		 }
	
	
	
	@Override
	public void start(Stage primaryStage) {
		try {
			
			Connection con = getConnection();
			PreparedStatement create = con.prepareStatement("DESCRIBE login");
			ResultSet result = create.executeQuery();
			
			BorderPane root1 = new BorderPane();
			Scene scene1 = new Scene(root1,500,700);
			root1.setStyle("-fx-background-image: url('bg.png'); ");
					
					
			BorderPane root2 = new BorderPane();
			Scene scene2 = new Scene(root2,500,700);
			root2.setStyle("-fx-background-image: url('bg.png'); ");
			
			BorderPane root3 = new BorderPane();
			Scene scene3 = new Scene(root3, 500, 700);
			root3.setStyle("-fx-background-image: url('bg.png'); ");
			
			BorderPane root4 = new BorderPane();
			Scene scene4 = new Scene(root4, 500, 700);
			root4.setStyle("-fx-background-image: url('bg.png'); ");
			
			
			//scene 1
			Image img = new Image("head.png");
			VBox v1 = new VBox();
			
			Button EB = new Button("Employee");
			EB.setTranslateY(100);
			EB.setTranslateX(190);
			EB.setFont(Font.font(null, FontWeight.BOLD, 17));
			EB.setUnderline(false);
			EB.setTextFill(Color.WHITE);
			EB.setMaxWidth(110);
			EB.setMinWidth(110);
			EB.setMaxHeight(45);
			EB.setMinHeight(45);
			EB.setStyle(" -fx-font-size: 1.4em; fx-color: #000000; -fx-background-color: #8b0100; -fx-background-radius: .5em; -fx-text-decoration: bold;");
			EB.setOnAction(new EventHandler<ActionEvent>() {
			    @Override public void handle(ActionEvent e) {
			    		primaryStage.setScene(scene1);
			    		primaryStage.show();
			    	}
			});
			
			Button SB = new Button("Student");
			SB.setTranslateY(120);
			SB.setTranslateX(190);
			SB.setFont(Font.font(null, FontWeight.BOLD, 17));
			SB.setUnderline(false);
			SB.setMaxWidth(110);
			SB.setTextFill(Color.WHITE);
			SB.setMinWidth(110);
			SB.setMaxHeight(45);
			SB.setMinHeight(45);
			SB.setStyle("-fx-text-decoration: bold; -fx-font-size: 1.4em; fx-color: #000000; -fx-background-color: #c8bc00; -fx-background-radius: .5em; -fx-text-decoration: bold;");
			SB.setOnAction(new EventHandler<ActionEvent>() {
			    @Override public void handle(ActionEvent e) {
			    		primaryStage.setScene(scene1);
			    		primaryStage.show();
			    	}
			});
			
			
			
			v1.getChildren().addAll(new ImageView(img), EB,  SB);
			root1.setCenter(v1);
			
			
			
			
			
			
			
			
			primaryStage.setScene(scene1);
			primaryStage.setTitle("Sun Devil Slices");
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
